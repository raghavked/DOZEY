
  # DOZEY website (Community)

  This is a code bundle for DOZEY website (Community). The original project is available at https://www.figma.com/design/lN28odvh5Znyod2e4BHGr1/DOZEY-website--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  