import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Navbar } from '@/app/components/navbar';
import { Footer } from '@/app/components/footer';
import { HomePage } from '@/app/pages/home';
import { FeaturesPage } from '@/app/pages/features';
import { ProgressPage } from '@/app/pages/progress';
import { TeamPage } from '@/app/pages/team';
import { ContactPage } from '@/app/pages/contact';

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-green-50/20 text-[#22283a]">
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/features" element={<FeaturesPage />} />
          <Route path="/progress" element={<ProgressPage />} />
          <Route path="/team" element={<TeamPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
        <Footer />
      </div>
    </BrowserRouter>
  );
}