import { Link, useLocation } from 'react-router-dom';
import dozeyLogo from 'figma:asset/db39f476989fbee8be9ff6750587bd1f003c65d8.png';

export function Navbar() {
  const location = useLocation();

  const links = [
    { to: '/', label: 'Home' },
    { to: '/features', label: 'Features' },
    { to: '/progress', label: 'Progress & Validation' },
    { to: '/team', label: 'Team' },
    { to: '/contact', label: 'Contact Us' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          <Link to="/" className="flex-shrink-0">
            <img src={dozeyLogo} alt="DOZEY" className="h-24" />
          </Link>
          
          <div className="hidden md:flex md:items-center md:space-x-8">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`text-sm font-medium transition-colors hover:text-[#1051a5] ${
                  location.pathname === link.to
                    ? 'text-[#1051a5]'
                    : 'text-[#22283a]'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <a
            href="https://forms.gle/Tr7WLVfQR6W3PeXb6"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:inline-flex items-center px-6 py-2.5 bg-[#1051a5] text-white rounded-lg hover:bg-[#0d4185] transition-all shadow-md hover:shadow-lg"
          >
            Join Waitlist
          </a>
        </div>
      </div>
    </nav>
  );
}